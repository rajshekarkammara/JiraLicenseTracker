package com.vvit.services.service;

import com.atlassian.application.api.ApplicationKey;
import com.vvit.services.utility.FieldValidationResult;

public interface InputValidator {
    FieldValidationResult validateGroupName(String groupName);
    FieldValidationResult validateEmailName(String emailName);
    FieldValidationResult validateLicenseCount(int count, ApplicationKey applicationKey);
    FieldValidationResult validateApplicationKey(String applicationKey);

}
