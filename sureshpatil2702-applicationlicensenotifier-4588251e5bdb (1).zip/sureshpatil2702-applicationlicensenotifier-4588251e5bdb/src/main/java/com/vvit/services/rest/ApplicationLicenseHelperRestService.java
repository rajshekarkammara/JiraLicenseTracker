package com.vvit.services.rest;

import com.atlassian.application.api.ApplicationKey;
import com.vvit.services.ao.UserLicenseNotifierModel;
import com.vvit.services.dbservice.ULNDbManager;
import com.vvit.services.service.ApplicationService;
import com.vvit.services.service.InputValidator;
import com.vvit.services.service.model.ApplicationModel;
import com.vvit.services.utility.FieldValidationResult;
import org.apache.log4j.Logger;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 * A resource of message.
 */
@Path("/config")
public class ApplicationLicenseHelperRestService {
    
    private final ULNDbManager ulnDbManager;

    private final InputValidator inputValidator;


    private final ApplicationService applicationService;

    public ApplicationLicenseHelperRestService(ULNDbManager ulnDbManager, InputValidator inputValidator, ApplicationService applicationService) {
        this.ulnDbManager = ulnDbManager;
        this.inputValidator = inputValidator;
        this.applicationService = applicationService;
    }

    private static final Logger LOGGER = Logger.getLogger(ApplicationLicenseHelperRestService.class);

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    public Response setApplicationLicenseDetails(ApplicationLicenseHelperRestServiceModel applicationLicenseHelperRestServiceModel)
    {
        LOGGER.debug("\n Application Key:"+applicationLicenseHelperRestServiceModel.getApplicationKey());
        LOGGER.debug("\n Group:"+applicationLicenseHelperRestServiceModel.getGroup());
        LOGGER.debug("\n Email:"+applicationLicenseHelperRestServiceModel.getEmail());
        LOGGER.debug("\n Limit:"+applicationLicenseHelperRestServiceModel.getLimit());
        try {
            FieldValidationResult appKeyValidationResult = inputValidator.validateApplicationKey(applicationLicenseHelperRestServiceModel.getApplicationKey());
            FieldValidationResult limitValidationResult = inputValidator.validateLicenseCount(applicationLicenseHelperRestServiceModel.getLimit(), ApplicationKey.valueOf(applicationLicenseHelperRestServiceModel.getApplicationKey()));
            FieldValidationResult emailValidationResult = inputValidator.validateEmailName(applicationLicenseHelperRestServiceModel.getEmail());
            FieldValidationResult groupValidationResult = inputValidator.validateGroupName(applicationLicenseHelperRestServiceModel.getGroup());
            List<FieldValidationResult> validationResultList = new ArrayList<>();
            if(appKeyValidationResult.getHasError()){
                validationResultList.add(appKeyValidationResult);
            }else if(limitValidationResult.getHasError()){
                validationResultList.add(limitValidationResult);
            }else if(groupValidationResult.getHasError()){
                validationResultList.add(groupValidationResult);
            }
            if(validationResultList.isEmpty()){
                LOGGER.debug("Valid inputs for " + applicationLicenseHelperRestServiceModel.getApplicationKey());
                UserLicenseNotifierModel userLicenseNotifierModel = getUserLicenseNotifierModel(applicationLicenseHelperRestServiceModel);
                ulnDbManager.setLicenseNotificationDetailsOfApplication(userLicenseNotifierModel);
                ApplicationModel applicationModel = new ApplicationModel();
                applicationModel.setApplicationKey(applicationLicenseHelperRestServiceModel.getApplicationKey());
                applicationService.updateApplicationDetails(applicationModel);
                applicationLicenseHelperRestServiceModel.setVersion(applicationModel.getVersion());
                applicationLicenseHelperRestServiceModel.setHasUnlimitedSeats(applicationModel.getHasUnlimitedSeats());
                applicationLicenseHelperRestServiceModel.setUsedUser(applicationModel.getUsedUser());
                applicationLicenseHelperRestServiceModel.setTotalUser(applicationModel.getTotalUser());
;
            }else{
                LOGGER.debug("Invalid input");
                return Response.status(Response.Status.FORBIDDEN).entity(validationResultList).build();
            }



        }catch (Exception e){
            LOGGER.error("Something went wrong while storing license details for application key:"+applicationLicenseHelperRestServiceModel.getApplicationKey());
            LOGGER.error(e.getMessage());
            return Response.status(Response.Status.FORBIDDEN).entity("Something went wrong while storing license details for application key:"+applicationLicenseHelperRestServiceModel.getApplicationKey()+ "Error:"+e.getMessage()).build();
        }
        
        return Response.ok(applicationLicenseHelperRestServiceModel).build();
    }
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response getApplicationLicenseDetails(@QueryParam("applicationKey") String applicationKey){
        try {
            UserLicenseNotifierModel detailsOfApplication = ulnDbManager.getLicenseNotificationDetailsOfApplication(applicationKey);
            if (detailsOfApplication !=  null){
                ApplicationLicenseHelperRestServiceModel applicationLicenseHelperRestServiceModel =
                        new ApplicationLicenseHelperRestServiceModel(detailsOfApplication.getLicenselimitLong(),
                                detailsOfApplication.getApplicationKey(),
                                detailsOfApplication.getGroup(),
                                detailsOfApplication.getEmail(),
                                detailsOfApplication.getApplicationName());
                return Response.ok(applicationLicenseHelperRestServiceModel).build();
            }else {
                return Response.status(Response.Status.BAD_REQUEST).entity("Application not found with Application key:"+applicationKey).build();
            }
        }catch (Exception e){
            LOGGER.error("Something went wrong while getting license details for application key:"+applicationKey);
            LOGGER.error(e.getMessage());
            return Response.status(Response.Status.FORBIDDEN).entity("Something went wrong while getting license details for application key:"+applicationKey+ "Error:"+e.getMessage()).build();
        }
    }
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("applications")
    public Response getLicenseApplications(){
        try {
            List<ApplicationModel> applicationModels = applicationService.getListOfApplication();
            if (applicationModels !=  null){
                List<ApplicationLicenseHelperRestServiceModel> applicationLicenseHelperRestServiceModels = new ArrayList<>();
                for (ApplicationModel applicationModel : applicationModels){
                    ApplicationLicenseHelperRestServiceModel applicationLicenseHelperRestServiceModel =
                            new ApplicationLicenseHelperRestServiceModel(
                                    applicationModel.getKey(),
                                    applicationModel.getName(),
                                    applicationModel.getHasUnlimitedSeats(),
                                    applicationModel.getUsedUser(),
                                    applicationModel.getUsedUser());
                    applicationLicenseHelperRestServiceModels.add(applicationLicenseHelperRestServiceModel);

                }

                return Response.ok(applicationLicenseHelperRestServiceModels).build();
            }else {
                return Response.status(Response.Status.BAD_REQUEST).entity("License Applications not found in the Jira.").build();
            }
        }catch (Exception e){
            LOGGER.error("Something went wrong while getting license applications ");
            LOGGER.error(e.getMessage());
            return Response.status(Response.Status.FORBIDDEN).entity("Something went wrong while getting license applications.Error:"+e.getMessage()).build();
        }
    }
    @DELETE
    @Produces({MediaType.APPLICATION_JSON})
    public Response deleteApplicationLicenseDetails(@QueryParam("applicationKey") String applicationKey){
        try {
            Boolean isSuccessfullyDeleted = ulnDbManager.deleteLicenseNotificationDetailsOfApplication(applicationKey);
            if (isSuccessfullyDeleted){
                 ApplicationLicenseHelperRestServiceModel appModel = new ApplicationLicenseHelperRestServiceModel();
                appModel.setApplicationKey(applicationKey);
                return Response.ok(appModel).build();
            }else {
                return Response.status(Response.Status.FORBIDDEN).entity("Application"+applicationKey+" configuration deleted successfully !").build();
            }
        }catch (Exception e){
            LOGGER.error("Something went wrong while deleting license details for application key:"+applicationKey);
            LOGGER.error(e.getMessage());
            return Response.status(Response.Status.FORBIDDEN).entity("Something went wrong while deleting license details for application key:"+applicationKey+ "Error:"+e.getMessage()).build();
        }
    }

    private UserLicenseNotifierModel getUserLicenseNotifierModel(ApplicationLicenseHelperRestServiceModel applicationLicenseHelperRestServiceModel) {
        UserLicenseNotifierModel userLicenseNotifierModel = new UserLicenseNotifierModel();
        userLicenseNotifierModel.setApplicationKey(applicationLicenseHelperRestServiceModel.getApplicationKey());
        userLicenseNotifierModel.setLicenselimitLong(applicationLicenseHelperRestServiceModel.getLimit());
        userLicenseNotifierModel.setEmail(applicationLicenseHelperRestServiceModel.getEmail());
        userLicenseNotifierModel.setGroup(applicationLicenseHelperRestServiceModel.getGroup());
        userLicenseNotifierModel.setApplicationName(applicationLicenseHelperRestServiceModel.getApplicationName());
        return userLicenseNotifierModel;
    }
}