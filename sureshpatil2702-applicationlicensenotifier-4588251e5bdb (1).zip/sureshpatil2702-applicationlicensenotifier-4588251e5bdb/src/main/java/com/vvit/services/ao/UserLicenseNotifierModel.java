package com.vvit.services.ao;

public class UserLicenseNotifierModel {

    int licenselimitLong ;

    String group;

    String email;

    String applicationKey;

    String applicationName;

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public int getLicenselimitLong() {
        return licenselimitLong;
    }

    public void setLicenselimitLong(int licenselimitLong) {
        this.licenselimitLong = licenselimitLong;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getApplicationKey() {
        return applicationKey;
    }

    public void setApplicationKey(String applicationKey) {
        this.applicationKey = applicationKey;
    }
}
