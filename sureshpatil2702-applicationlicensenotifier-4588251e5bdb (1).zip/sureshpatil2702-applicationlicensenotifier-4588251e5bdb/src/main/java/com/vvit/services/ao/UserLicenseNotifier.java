package com.vvit.services.ao;

import net.java.ao.Entity;
import net.java.ao.Preload;
import net.java.ao.schema.NotNull;
import net.java.ao.schema.StringLength;
import net.java.ao.schema.Table;
import net.java.ao.schema.Unique;
//select * from "AO_75BFAC_LICENSE_NOTIFIER"
@Preload
@Table("License_Notifier")
public interface UserLicenseNotifier extends Entity {

    public int getLicenselimitLong();

    public void setLicenselimitLong(int licenselimitLong);

    @StringLength(StringLength.UNLIMITED)
    public String getGroup() ;

    public void setGroup(String group);

    @StringLength(StringLength.UNLIMITED)
    public String getEmail();

    public void setEmail(String email);

    @NotNull
    @Unique
    public String getApplicationKey();

    public void setApplicationKey(String applicationKey);

    @StringLength(StringLength.UNLIMITED)
    public String getApplicationName();

    public void setApplicationName(String applicationName);
}
