package com.vvit.services.rest;

public class ApplicationConfModel {

        Long licenselimitLong ;

        String group;

        String email;

        String applicationKey;

        public Long getLicenselimitLong() {
            return licenselimitLong;
        }

        public void setLicenselimitLong(Long licenselimitLong) {
            this.licenselimitLong = licenselimitLong;
        }

        public String getGroup() {
            return group;
        }

        public void setGroup(String group) {
            this.group = group;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getApplicationKey() {
            return applicationKey;
        }

        public void setApplicationKey(String applicationKey) {
            this.applicationKey = applicationKey;
        }

}
