package com.vvit.services.service;

import com.vvit.services.ao.UserLicenseNotifierModel;
import com.vvit.services.service.model.ApplicationModel;

import java.util.List;

public interface ApplicationService {
    List<ApplicationModel> getListOfApplication();
    List<ApplicationModel> getConfiguredApplications();
    void updateApplicationDetails(ApplicationModel applicationModel);

}
