package com.vvit.services.dbservice;

import com.atlassian.activeobjects.tx.Transactional;
import com.vvit.services.ao.UserLicenseNotifierModel;
import com.vvit.services.service.model.ApplicationModel;

import java.util.List;

@Transactional
public interface ULNDbManager {
    UserLicenseNotifierModel getLicenseNotificationDetailsOfApplication(String application);
    UserLicenseNotifierModel setLicenseNotificationDetailsOfApplication(UserLicenseNotifierModel detailsOfApplication);
    List<ApplicationModel> getAllLicenseNotificationDetails();
    Boolean deleteLicenseNotificationDetailsOfApplication(String applicationKey);
}
