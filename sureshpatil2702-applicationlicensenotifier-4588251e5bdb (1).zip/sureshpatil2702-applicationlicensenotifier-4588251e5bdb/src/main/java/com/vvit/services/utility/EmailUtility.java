package com.vvit.services.utility;

public class EmailUtility {
}
