package com.vvit.services.utility;

import org.codehaus.jackson.annotate.JsonProperty;

public class FieldValidationResult {
    @JsonProperty
    String field;
    @JsonProperty
    Boolean hasError;
    @JsonProperty
    String response;

    public FieldValidationResult(String field, Boolean hasError, String response) {
        this.field = field;
        this.hasError = hasError;
        this.response = response;
    }

    public FieldValidationResult(){};
    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public Boolean getHasError() {
        return hasError;
    }

    public void setHasError(Boolean hasError) {
        this.hasError = hasError;
    }
}
