package com.vvit.services.service.impl;

import com.atlassian.jira.security.groups.GroupManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.mail.Email;
import com.atlassian.mail.MailException;
import com.atlassian.mail.server.MailServerManager;
import com.atlassian.mail.server.SMTPMailServer;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.vvit.services.service.NotificationService;
import com.vvit.services.utility.NotificationModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Named;
import java.util.Collection;

@Named("notificationService")
public class NotificationServiceImpl implements NotificationService {
    private static final Logger logger = LoggerFactory.getLogger(NotificationServiceImpl.class);
    @ComponentImport
    final MailServerManager mailServerManager;

    @ComponentImport
    private final GroupManager groupManager;

    public NotificationServiceImpl(MailServerManager mailServerManager, GroupManager groupManager) {
        this.mailServerManager = mailServerManager;
        this.groupManager = groupManager;
    }

    /**
     * @param notificationModel
     */
    @Override
    public void notifyGroup(NotificationModel notificationModel) {

        String groupName = notificationModel.getGroupName();
        try{
            if(groupName!= null){
                String groupEmails = getUserEmailsOfGroup(notificationModel.getGroupName());
                sendEmail(notificationModel,groupEmails);
            }
        }catch (Exception e){
            logger.error("Something went wrong while sending notification to group :"+groupName);
            logger.error(e.getMessage());

        }
    }

    /**
     * @param notificationModel
     */

    /*
    * Change email tempalte with limit and exceed
    * */
    @Override
    public void notifyEmail(NotificationModel notificationModel) {
        try{

                String emailAddress = notificationModel.getEmail();
                sendEmail(notificationModel,emailAddress);


        }catch (Exception e){
            logger.error("Something went wrong while sending notification to email :"+notificationModel.getEmail() +"and Group:"+notificationModel.getGroupName());
            logger.error(e.getMessage());

        }

    }
    private void sendEmail(NotificationModel notificationModel,String emailAddresses){
        try{
            if (mailServerManager != null){
                Email email = new Email(emailAddresses);
                email.setSubject("Urgent: User License Limit Exceeded for "+notificationModel.getApplicationName());
                String body = "Hello,<br>" +
                        "<br>" +
                        "The License Tracking for Jira add-on has identified that the user license limit for the <b>"+notificationModel.getApplicationName()+"</b> application has been surpassed. Immediate action is required to address this issue and prevent potential complications.<br>" +
                        "<br>" +
                        "Here are the details:<br>" +
                        "<ul>" +
                        "<li>License purchased for: <b>"+notificationModel.getTotalLicenseCount()+" </b>users</li>" +
                        "<li>License limit configured for: <b>"+notificationModel.getLimit()+" </b>users</li>" +
                        "<li>Current user count: <b>"+notificationModel.getCurrentUserCount()+" </b>users</li>" +
                        "</ul>" +
                        "<div>Please take prompt measures to rectify the situation and ensure compliance with the license agreement.<br>" +
                        "<br>" +
                        "Thank you," +
                        "<br>" +
                        "License Tracking for Jira" +
                        "<br>" +
                        "</div>";


                email.setBody(body);
                email.setMimeType("text/html");
                SMTPMailServer mailServer = mailServerManager.getDefaultSMTPMailServer();
                mailServer.send(email);
                logger.debug("\n Email sent to"+emailAddresses);
            }else {
                logger.debug("Mail server not configured");
            }
        }catch (MailException mailException){
            logger.error("Could not send email with email address :"+emailAddresses);
            logger.error(mailException.getMessage());
        }catch (Exception e){
            logger.error("Something went wrong while sending notification to email :"+emailAddresses);
            logger.error(e.getMessage());

        }
    }
    private  String getUserEmailsOfGroup(String groupName) {
        StringBuilder emails = new StringBuilder();
        try{
            Collection<ApplicationUser> users = groupManager.getUsersInGroup(groupName);

            for (ApplicationUser user : users){
                String email = user.getEmailAddress();
                emails.append(email);
                emails.append(",");
            }
            emails.deleteCharAt(emails.lastIndexOf(emails.toString()));
        }catch (Exception e){
            logger.error("Something went wrong while getting user emails  from group:"+groupName);
        }
        return emails.toString();
    }
}
