package com.vvit.services.webwork;

import com.atlassian.jira.security.request.RequestMethod;
import com.atlassian.jira.security.request.SupportedMethods;
import com.vvit.services.ao.UserLicenseNotifierModel;
import com.vvit.services.service.ApplicationService;
import com.vvit.services.service.model.ApplicationModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.atlassian.jira.web.action.JiraWebActionSupport;

import java.util.List;

@SupportedMethods({RequestMethod.GET, RequestMethod.POST})
public class UserLicenseConfigurationAction extends JiraWebActionSupport
{
    private static final Logger log = LoggerFactory.getLogger(UserLicenseConfigurationAction.class);
    private List<ApplicationModel>  applications;
    private Long licenselimit;
    private String group;
    private String email;
    private String application;

    private final ApplicationService applicationService;

    public UserLicenseConfigurationAction(ApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    @SupportedMethods({RequestMethod.POST})
    public String doExecute() throws Exception {
        return SUCCESS;
    }
    @SupportedMethods({RequestMethod.GET})
    public String doDefault() throws Exception{
        this.applications = applicationService.getConfiguredApplications();
        return SUCCESS;
    }

    public Long getLicenselimit() {
        return licenselimit;
    }

    public void setLicenselimit(Long licenselimit) {
        this.licenselimit = licenselimit;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }

    public List<ApplicationModel> getApplications() {
        return applications;
    }

    public void setApplications() {
        log.debug("\n list of application loading...");
        this.applications = applicationService.getConfiguredApplications();
    }
}
