package com.vvit.services.job;


import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.scheduler.*;
import com.atlassian.scheduler.config.JobConfig;
import com.atlassian.scheduler.config.JobId;
import com.atlassian.scheduler.config.JobRunnerKey;
import com.atlassian.scheduler.config.Schedule;
import com.vvit.services.service.UserLicenseService;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.inject.Named;

import java.util.concurrent.TimeUnit;

import static com.atlassian.scheduler.config.JobConfig.forJobRunnerKey;
import static com.atlassian.scheduler.config.RunMode.RUN_ONCE_PER_CLUSTER;


@Named
public class LicenseUserNotificationJob implements JobRunner, InitializingBean, DisposableBean {
    private final static String IDENTIFIER = LicenseUserNotificationJob.class.getName();
    private static final Logger LOGGER = Logger.getLogger(LicenseUserNotificationJob.class);
    private final static JobRunnerKey JOB_RUNNER_KEY = JobRunnerKey.of(IDENTIFIER);
    private final static JobId JOB_ID = JobId.of(IDENTIFIER);

    @ComponentImport
    private final SchedulerService schedulerService;

    private final UserLicenseService userLicenseService;

    public LicenseUserNotificationJob(SchedulerService schedulerService, UserLicenseService userLicenseService) {
        this.schedulerService = schedulerService;
        this.userLicenseService = userLicenseService;
    }

    @Nullable
    @Override
    public JobRunnerResponse runJob(@Nonnull JobRunnerRequest jobRunnerRequest) {
        LOGGER.debug("Job executed...");

        userLicenseService.checkUserLicenseLimitAndNotifyGroupIfExceed();
        return JobRunnerResponse.success("Success");
    }

    @Override
    public void destroy() throws Exception {
        LOGGER.debug("Job destroyed ...");

        schedulerService.unscheduleJob(JOB_ID);

    }

    @Override
    public void afterPropertiesSet() throws Exception {
        schedulerService.registerJobRunner(JOB_RUNNER_KEY, this);
        final JobConfig configuration = forJobRunnerKey(JOB_RUNNER_KEY)
                .withRunMode(RUN_ONCE_PER_CLUSTER)
               /* .withSchedule(Schedule.forCronExpression("0 0 * * * ?"));*/
                .withSchedule(Schedule.forInterval(TimeUnit.DAYS.toMillis(1), new DateTime()
                        .withTimeAtStartOfDay()
                        .plusDays(1)
                        .toDate()));


        try {
            schedulerService.scheduleJob(JOB_ID, configuration);
        } catch (SchedulerServiceException e) {
            LOGGER.error("Something went wrong while executing job. "+e.getMessage());
        }
    }
}