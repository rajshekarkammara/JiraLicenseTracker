package com.vvit.services.service.model;

import com.vvit.services.ao.UserLicenseNotifierModel;

public class ApplicationModel extends UserLicenseNotifierModel {


    String name;
    String version;
    String key;
    Boolean hasUnlimitedSeats;
    int totalUser;
    int usedUser;
    int limit;

    String email;

    String group;

    public ApplicationModel() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Boolean getHasUnlimitedSeats() {
        return hasUnlimitedSeats;
    }

    public void setHasUnlimitedSeats(Boolean hasUnlimitedSeats) {
        this.hasUnlimitedSeats = hasUnlimitedSeats;
    }

    public int getTotalUser() {
        return totalUser;
    }

    public void setTotalUser(int totalUser) {
        this.totalUser = totalUser;
    }

    public int getUsedUser() {
        return usedUser;
    }

    public void setUsedUser(int usedUser) {
        this.usedUser = usedUser;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }
}
