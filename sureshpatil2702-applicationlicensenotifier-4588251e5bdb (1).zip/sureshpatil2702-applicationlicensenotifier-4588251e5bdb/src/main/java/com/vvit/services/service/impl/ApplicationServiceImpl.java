package com.vvit.services.service.impl;

import com.atlassian.application.api.Application;
import com.atlassian.application.api.ApplicationKey;
import com.atlassian.extras.api.jira.JiraLicense;
import com.atlassian.jira.application.JiraApplicationManager;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.license.JiraLicenseManager;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.vvit.services.ao.UserLicenseNotifierModel;
import com.vvit.services.dbservice.ULNDbManager;
import com.vvit.services.service.ApplicationService;
import com.vvit.services.service.UserLicenseService;
import com.vvit.services.service.model.ApplicationModel;
import org.apache.log4j.Logger;


import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Named("applicationService")
public class ApplicationServiceImpl implements ApplicationService {

    private static final Logger LOGGER = Logger.getLogger(ApplicationServiceImpl.class);

    private final JiraApplicationManager jiraApplicationManager;

    @ComponentImport
    private final JiraLicenseManager jiraLicenseManager;
    private final UserLicenseService userLicenseService;
    private final ULNDbManager ulnDbManager;
    @Inject
    public ApplicationServiceImpl(JiraLicenseManager jiraLicenseManager, UserLicenseService userLicenseService, ULNDbManager ulnDbManager) {
        this.ulnDbManager = ulnDbManager;
        this.jiraApplicationManager = ComponentAccessor.getComponent(JiraApplicationManager.class);
        this.jiraLicenseManager = jiraLicenseManager;
        this.userLicenseService = userLicenseService;
    }

    /**
     * @return
     */
    @Override
    public List<ApplicationModel> getListOfApplication() {


        List<ApplicationModel> applicationModelList = new ArrayList<>();
        try {
            LOGGER.debug("\n getting list of applications");
            Set<ApplicationKey> licensedApplicationsKeys = jiraLicenseManager.getAllLicensedApplicationKeys();
            for (ApplicationKey applicationKey : licensedApplicationsKeys) {
                ApplicationModel applicationModel = new ApplicationModel();
                Application application = jiraApplicationManager.getApplication(applicationKey).getOrNull();
                if(application != null){
                    LOGGER.debug("Application Key:"+applicationKey.value());
                    applicationModel.setKey(applicationKey.value());
                    LOGGER.debug("Application Name:"+application.getName());
                    applicationModel.setName(application.getName());
                    LOGGER.debug("Application Version:"+application.getVersion());
                    applicationModel.setVersion(application.getVersion());

                    JiraLicense jiraLicense = jiraLicenseManager.getLicense(applicationKey).get().getJiraLicense();
                    if(jiraLicense != null){
                        if(jiraLicense.isUnlimitedNumberOfUsers()){
                            LOGGER.debug("Maximum User Count: Unlimited");
                            applicationModel.setHasUnlimitedSeats(true);
                        }else{
                            LOGGER.debug("Maximum User Count: "+application.getAccess().getMaximumUserCount().get());
                            applicationModel.setHasUnlimitedSeats(false);
                            applicationModel.setTotalUser(userLicenseService.getNumberOfSeats(application.getKey()));

                        }
                    }
                    LOGGER.debug("Application Licensed User:"+userLicenseService.getNumberOfLisensedUsers(application.getKey()));
                    applicationModel.setUsedUser(userLicenseService.getNumberOfLisensedUsers(applicationKey));

                    UserLicenseNotifierModel ulnModel = userLicenseService.getUserLicenseNotificationDetailsOfApplication(application.getKey().value());
                    if (ulnModel != null) {
                        applicationModel.setLimit(ulnModel.getLicenselimitLong());
                        applicationModel.setEmail(ulnModel.getEmail());
                        applicationModel.setGroup(ulnModel.getGroup());
                    }else {
                        applicationModelList.add(applicationModel);
                    }

                }else{
                    LOGGER.debug("Jira application not found with key:"+applicationKey.value());
                }

            }
        }catch (Exception e){
            e.printStackTrace();
            LOGGER.error("\n Something went wrong while loading list of applications."+e.getMessage());
        }
         return applicationModelList;
    }

    /**
     * @return
     */
    @Override
    public List<ApplicationModel> getConfiguredApplications() {
        List<ApplicationModel> applicationModels = null;
        try {
            applicationModels = ulnDbManager.getAllLicenseNotificationDetails();
            for (ApplicationModel applicationModel : applicationModels){
                updateApplicationDetails(applicationModel);
            }
        }catch (Exception e){
            e.printStackTrace();
            LOGGER.error("\n Something went wrong while loading list of configured applications."+e.getMessage());
        }
        return  applicationModels;
    }

    public void updateApplicationDetails(ApplicationModel applicationModel){
        try {
            LOGGER.debug("Application Key:"+applicationModel.getApplicationKey());
            Application application = jiraApplicationManager.getApplication(ApplicationKey.valueOf(applicationModel.getApplicationKey())).getOrNull();
            if(application != null){

                LOGGER.debug("Application Version:"+application.getVersion());
                applicationModel.setVersion(application.getVersion());

                JiraLicense jiraLicense = jiraLicenseManager.getLicense(application.getKey()).get().getJiraLicense();
                if(jiraLicense != null){
                    if(jiraLicense.isUnlimitedNumberOfUsers()){
                        LOGGER.debug("Maximum User Count: Unlimited");
                        applicationModel.setHasUnlimitedSeats(true);
                    }else{
                        LOGGER.debug("Maximum User Count: "+application.getAccess().getMaximumUserCount().get());
                        applicationModel.setHasUnlimitedSeats(false);
                        applicationModel.setTotalUser(userLicenseService.getNumberOfSeats(application.getKey()));

                    }
                }
                LOGGER.debug("Application Licensed User:"+userLicenseService.getNumberOfLisensedUsers(application.getKey()));
                applicationModel.setUsedUser(userLicenseService.getNumberOfLisensedUsers(application.getKey()));

            }else{
                LOGGER.debug("Jira application not found with key:"+applicationModel.getApplicationKey());
            }
        }catch (Exception e){
            e.printStackTrace();
            LOGGER.error("\n Something went wrong while getting application details of ."+applicationModel.getApplicationKey());
        }
    }

}
