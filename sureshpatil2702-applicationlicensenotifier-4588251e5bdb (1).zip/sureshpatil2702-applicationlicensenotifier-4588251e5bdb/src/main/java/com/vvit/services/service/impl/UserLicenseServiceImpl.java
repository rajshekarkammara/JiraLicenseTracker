package com.vvit.services.service.impl;

import com.atlassian.application.api.ApplicationKey;
import com.atlassian.extras.api.jira.JiraLicense;
import com.atlassian.jira.application.ApplicationRole;
import com.atlassian.jira.application.ApplicationRoleManager;
import com.atlassian.jira.license.JiraLicenseManager;
import com.atlassian.jira.license.LicenseDetails;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.vvit.services.ao.UserLicenseNotifierModel;
import com.vvit.services.dbservice.ULNDbManager;
import com.vvit.services.service.NotificationService;
import com.vvit.services.service.UserLicenseService;
import com.vvit.services.service.model.ApplicationModel;
import com.vvit.services.utility.NotificationModel;
import org.apache.log4j.Logger;

import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

@Named("userLicenseService")
public class UserLicenseServiceImpl implements UserLicenseService {
    @ComponentImport
    private final JiraLicenseManager jiraLicenseManager;
    @ComponentImport
    private final ApplicationRoleManager applicationRoleManager;

    private final ULNDbManager ulnDbManager;

    private final NotificationService notificationService;


    private final Logger logger = Logger.getLogger(UserLicenseServiceImpl.class);

    public UserLicenseServiceImpl(JiraLicenseManager jiraLicenseManager,
                                  ApplicationRoleManager applicationRoleManager,
                                  ULNDbManager ulnDbManager, NotificationService notificationService
                                  ) {
        this.jiraLicenseManager = jiraLicenseManager;
        this.applicationRoleManager = applicationRoleManager;
        this.ulnDbManager = ulnDbManager;
        this.notificationService = notificationService;
    }

    @Override
    public void checkUserLicenseLimitAndNotifyGroupIfExceed() {
        Iterable<LicenseDetails> licenseDetails = jiraLicenseManager.getLicenses();
        List<NotificationModel> notificationModels = new ArrayList<>();
        licenseDetails.forEach(licenseDetails1 -> {
            logger.debug("Application Description:" + licenseDetails1.getApplicationDescription());
            logger.debug("Application Jira License Description:" + licenseDetails1.getJiraLicense().getDescription());
        });

        List<ApplicationModel> allLicenseNotificationDetails = ulnDbManager.getAllLicenseNotificationDetails();
        for (final UserLicenseNotifierModel userLicenseNotifierModel : allLicenseNotificationDetails) {
            String applicationKey = userLicenseNotifierModel.getApplicationKey();
            int limit = userLicenseNotifierModel.getLicenselimitLong();
            int licensedUsers = getNumberOfLisensedUsers(ApplicationKey.valueOf(applicationKey));
            String totalUsers;
            String appName = "";
            ApplicationRole applicationRole = applicationRoleManager.getRole(ApplicationKey.valueOf(applicationKey)).get();
            if (applicationRole != null) {
                appName = applicationRole.getName();
            }
            if (isUnlimitedLicenseApplication(applicationKey)) {
                totalUsers = "UNLIMITED";
            } else {
                totalUsers = String.valueOf(getNumberOfSeats(ApplicationKey.valueOf(applicationKey)));
            }

            if (isApplicationLimitExceedLimit(limit, ApplicationKey.valueOf(applicationKey))) {
                logger.info("Limit exceed send email notification");
                notificationModels.add(new NotificationModel(applicationKey, appName, limit, true,
                        userLicenseNotifierModel.getEmail(), userLicenseNotifierModel.getGroup(), licensedUsers, totalUsers));
            } else {
                logger.debug("\n Application " + applicationKey + " limit : " + limit + " not exceed");
            }
        }
        if (!notificationModels.isEmpty()) {
            /*Send email Notification*/
            for (NotificationModel notificationModel : notificationModels) {
                notificationService.notifyEmail(notificationModel);
                notificationService.notifyGroup(notificationModel);
            }

        } else {
            logger.debug("\n Applications limit not exceed");
        }

    }

    private boolean isApplicationLimitExceedLimit(int limit, ApplicationKey applicationKey) {
        logger.debug("Limit:" + limit);
        logger.debug("getNumberOfLisensedUsers():" + getNumberOfLisensedUsers(applicationKey));
        logger.debug("isApplicationLimitExceedLimit():" + (getNumberOfLisensedUsers(applicationKey) > limit));
        return getNumberOfLisensedUsers(applicationKey) > limit;
    }

    public int getNumberOfLisensedUsers(ApplicationKey applicationKey) {
        return applicationRoleManager.getUserCountAsync(applicationKey);
    }

    public int getNumberOfSeats(ApplicationKey applicationKey) {
        int numberOfSeates = 0;
        try {
            numberOfSeates = applicationRoleManager.getRole(applicationKey).get().getNumberOfSeats();
        } catch (Exception e) {
            logger.error("Something went wrong while getting number of seats for applicationkey" + applicationKey);
            logger.error(e.getMessage());
        }
        return numberOfSeates;
    }

    /**
     * @param userLicenseNotifierModel
     */
    @Override
    public void addUserLicenseNotificationDetails(UserLicenseNotifierModel userLicenseNotifierModel) {
        try {
            UserLicenseNotifierModel uLicenseNotifierModel = ulnDbManager.setLicenseNotificationDetailsOfApplication(userLicenseNotifierModel);
        } catch (Exception e) {
            logger.error("Something went while adding UserLicense Notification Details");
            logger.error(e.getMessage());
        }
    }

    /**
     * @param applicationKey
     * @return
     */
    @Override
    public UserLicenseNotifierModel getUserLicenseNotificationDetailsOfApplication(String applicationKey) {
        UserLicenseNotifierModel uLicenseNotifierModel = null;
        try {

            uLicenseNotifierModel = ulnDbManager.getLicenseNotificationDetailsOfApplication(applicationKey);
        } catch (Exception e) {
            logger.error("Something went while getting UserLicense Notification Details");
            logger.error(e.getMessage());
        }
        return uLicenseNotifierModel;
    }

    /**
     * @return
     */
    @Override
    public List<ApplicationModel> getAllUserLicenseNotificationDetailsApp() {
        List<ApplicationModel> uLicenseNotifierModels = new ArrayList<>();
        try {
            uLicenseNotifierModels = ulnDbManager.getAllLicenseNotificationDetails();
        } catch (Exception e) {
            logger.error("Something went while getting UserLicense Notification Details");
            logger.error(e.getMessage());
        }
        return uLicenseNotifierModels;

    }

    public boolean isUnlimitedLicenseApplication(String applicationKey) {
        try {
            JiraLicense jiraLicense = jiraLicenseManager.getLicense(ApplicationKey.valueOf(applicationKey)).get().getJiraLicense();
            if (jiraLicense != null) {
                if (jiraLicense.isUnlimitedNumberOfUsers()) {
                    return true;
                }
            }
        } catch (Exception e) {
            logger.error("Something went wrong while checking unlimited user license for application." + applicationKey);
            logger.error(e.getMessage());
        }
        return false;
    }
}
