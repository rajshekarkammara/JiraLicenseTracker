package com.vvit.services.dbservice.impl;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.vvit.services.ao.UserLicenseNotifier;
import com.vvit.services.ao.UserLicenseNotifierModel;
import com.vvit.services.dbservice.ULNDbManager;
import com.vvit.services.service.model.ApplicationModel;
import net.java.ao.DBParam;
import net.java.ao.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
@Named("uLNDbManager")
public class ULNDbManagerImpl implements ULNDbManager {
    /**
     * @param application
     * @return
     */
    private static final Logger log = LoggerFactory.getLogger(ULNDbManagerImpl.class);

    @ComponentImport
    private final ActiveObjects activeObjects;
    @Inject
    public ULNDbManagerImpl(ActiveObjects activeObjects) {
        this.activeObjects = activeObjects;
    }




    @Override
    public UserLicenseNotifierModel getLicenseNotificationDetailsOfApplication(String application) {

        UserLicenseNotifierModel userLicenseNotifierModel = null;
        try {

            final UserLicenseNotifier[] userLicenseNotifiers = activeObjects.find(UserLicenseNotifier.class, Query.select().where("APPLICATION_KEY = ?", application));
            if (userLicenseNotifiers.length > 0) { /*Exist*/
                userLicenseNotifierModel = new UserLicenseNotifierModel();
                log.debug("License Notification details are stored for application:" + userLicenseNotifiers[0].getApplicationKey());
                userLicenseNotifierModel.setApplicationKey(userLicenseNotifiers[0].getApplicationKey());
                userLicenseNotifierModel.setLicenselimitLong(userLicenseNotifiers[0].getLicenselimitLong());
                userLicenseNotifierModel.setGroup(userLicenseNotifiers[0].getGroup());
                userLicenseNotifierModel.setEmail(userLicenseNotifiers[0].getEmail());
                userLicenseNotifierModel.setApplicationName(userLicenseNotifiers[0].getApplicationName());
            }
        } catch (Exception e) {
            log.error("Something went wrong while adding License Notification Details to Db table");
            log.error(e.getMessage());
        }
        return userLicenseNotifierModel;
    }

    /**}
     * @param detailsOfApplication
     */
    @Override
    public UserLicenseNotifierModel setLicenseNotificationDetailsOfApplication(UserLicenseNotifierModel detailsOfApplication) {
        try{
            log.debug("\n string application configuraton:"+detailsOfApplication.getApplicationKey());
            final UserLicenseNotifier [] userLicenseNotifiers = activeObjects.find(UserLicenseNotifier.class, Query.select().where("APPLICATION_KEY = ?",detailsOfApplication.getApplicationKey()));
            if(userLicenseNotifiers.length > 0){ /*Exist*/
                log.debug("License Notification details are stored for application:"+detailsOfApplication.getApplicationKey());
                userLicenseNotifiers[0].setApplicationKey(detailsOfApplication.getApplicationKey());
                userLicenseNotifiers[0].setLicenselimitLong(detailsOfApplication.getLicenselimitLong());
                userLicenseNotifiers[0].setGroup(detailsOfApplication.getGroup());
                userLicenseNotifiers[0].setEmail(detailsOfApplication.getEmail());
                userLicenseNotifiers[0].setApplicationName(detailsOfApplication.getApplicationName());
                userLicenseNotifiers[0].save();
            }else{/*New entry*/
                log.debug("License Notification details are not stored for application:"+detailsOfApplication.getApplicationKey());
                log.debug("limit:"+detailsOfApplication.getLicenselimitLong());
                log.debug("email:"+detailsOfApplication.getEmail());
                log.debug("group:"+detailsOfApplication.getGroup());
                final UserLicenseNotifier userLicenseNotifier = activeObjects.create(UserLicenseNotifier.class,
                        new DBParam("APPLICATION_KEY",detailsOfApplication.getApplicationKey()));
                 userLicenseNotifier.setLicenselimitLong(detailsOfApplication.getLicenselimitLong());
                 userLicenseNotifier.setGroup(detailsOfApplication.getGroup());
                 userLicenseNotifier.setEmail(detailsOfApplication.getEmail());
                 userLicenseNotifier.setApplicationName(detailsOfApplication.getApplicationName());
                 userLicenseNotifier.save();
            }
            return detailsOfApplication;
        }catch (Exception e){
            log.error("Something went wrong while adding License Notification Details to Db table");
            log.error(e.getMessage());
            return null;
        }
    }

    /**
     * @return
     */
    @Override
    public List<ApplicationModel> getAllLicenseNotificationDetails() {
        List<ApplicationModel> applicationModels = new ArrayList<>();
        try {

            final UserLicenseNotifier[] userLicenseNotifiers = activeObjects.find(UserLicenseNotifier.class);

                for (UserLicenseNotifier userLicenseNotifier : userLicenseNotifiers){
                    ApplicationModel applicationModel = getApplicationModel(userLicenseNotifier);
                    applicationModels.add(applicationModel);
                }
        } catch (Exception e) {
            log.error("Something went wrong while adding License Notification Details to Db table");
            log.error(e.getMessage());
        }
        return applicationModels;
    }

    private static ApplicationModel getApplicationModel(UserLicenseNotifier userLicenseNotifier) {
        ApplicationModel applicationModel = new ApplicationModel();
        applicationModel.setApplicationKey(userLicenseNotifier.getApplicationKey());
        applicationModel.setLicenselimitLong(userLicenseNotifier.getLicenselimitLong());
        applicationModel.setGroup(userLicenseNotifier.getGroup());
        applicationModel.setEmail(userLicenseNotifier.getEmail());
        applicationModel.setApplicationName(userLicenseNotifier.getApplicationName());
        return applicationModel;
    }

    /**
     * @param applicationKey
     * @return
     */
    @Override
    public Boolean deleteLicenseNotificationDetailsOfApplication(String applicationKey) {
        try {
            final UserLicenseNotifier [] userLicenseNotifiers = activeObjects.find(UserLicenseNotifier.class, Query.select().where("APPLICATION_KEY = ?",applicationKey));
            if(userLicenseNotifiers.length > 0) { /*Exist*/
                activeObjects.delete(userLicenseNotifiers);
                log.debug("Successfully deleted the application configuration for license limit. Application Key:"+applicationKey);
                return true;
            }
        }catch (Exception e){
            log.error("Something went wrong while deleting License Notification Details from Db table"+applicationKey);
            log.error(e.getMessage());
        }
        return false;
    }
}
