package com.vvit.services.listners;

import com.atlassian.crowd.event.user.UserCreatedEvent;
import com.atlassian.crowd.model.user.User;
import com.atlassian.event.api.EventListener;
import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.web.pagebuilder.JiraPageBuilderService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.webresource.api.assembler.WebResourceAssembler;
import com.vvit.services.service.UserLicenseService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import javax.inject.Inject;

public class UserCreateEventListener implements InitializingBean, DisposableBean {

    private static final Logger LOGGER = Logger.getLogger(UserCreateEventListener.class);
    @ComponentImport
    private final EventPublisher eventPublisher;
    @ComponentImport
    JiraPageBuilderService jiraPageBuilderService;
    private final UserLicenseService userLicenseService;
    @Inject
    public UserCreateEventListener(EventPublisher eventPublisher, UserLicenseService userLicenseService,
                                   JiraPageBuilderService jiraPageBuilderService,
                                   WebResourceAssembler webResourceAssembler) {
        this.eventPublisher = eventPublisher;
        this.userLicenseService = userLicenseService;
        this.jiraPageBuilderService =jiraPageBuilderService;
    }

    /**
     * Called when the plugin has been enabled.
     * @throws Exception
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        LOGGER.info("Enabling plugin listner");
        eventPublisher.register(this);
    }

    /**
     * Called when the plugin is being disabled or removed.
     * @throws Exception
     */
    @Override
    public void destroy() throws Exception {
        LOGGER.info("Disabling plugin listner");
        eventPublisher.unregister(this);
    }

    @EventListener
    public void OnUserEvent(UserCreatedEvent userCreatedEvent){

        User user = userCreatedEvent.getUser();
        LOGGER.debug("User created event trigger : "+user.getDisplayName());
        userLicenseService.checkUserLicenseLimitAndNotifyGroupIfExceed();

    }
}
