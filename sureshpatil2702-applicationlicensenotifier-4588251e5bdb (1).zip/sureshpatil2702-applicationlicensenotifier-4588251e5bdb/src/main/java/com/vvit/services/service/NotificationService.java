package com.vvit.services.service;

import com.vvit.services.utility.NotificationModel;

public interface NotificationService {
    void notifyGroup(NotificationModel notificationModel);
    void notifyEmail(NotificationModel notificationModel);
}
