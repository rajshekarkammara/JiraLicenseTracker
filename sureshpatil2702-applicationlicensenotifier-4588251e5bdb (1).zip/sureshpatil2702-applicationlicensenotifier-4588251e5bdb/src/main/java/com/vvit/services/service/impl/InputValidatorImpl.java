package com.vvit.services.service.impl;


import com.atlassian.application.api.ApplicationKey;
import com.atlassian.crowd.embedded.api.Group;
import com.atlassian.jira.application.ApplicationRoleManager;
import com.atlassian.jira.license.JiraLicenseManager;
import com.atlassian.jira.license.LicenseDetails;
import com.atlassian.jira.license.LicensedApplications;
import com.atlassian.jira.security.groups.GroupManager;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.vvit.services.service.InputValidator;
import com.vvit.services.utility.FieldValidationResult;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Named("inputValidator")
public class InputValidatorImpl implements InputValidator {

    private static final Logger LOGGER = Logger.getLogger(InputValidatorImpl.class);

    @ComponentImport
    private final GroupManager groupManager;

    @ComponentImport
    private final JiraLicenseManager jiraLicenseManager;

    @ComponentImport
    private final ApplicationRoleManager applicationRoleManager;

    @Inject
    public InputValidatorImpl(GroupManager groupManager, JiraLicenseManager jiraLicenseManager, ApplicationRoleManager applicationRoleManager) {
        this.groupManager = groupManager;
        this.jiraLicenseManager = jiraLicenseManager;
        this.applicationRoleManager = applicationRoleManager;
    }
    /**
     * @param groupName
     * @return
     */
    @Override
    public FieldValidationResult validateGroupName(String groupName) {
        FieldValidationResult fieldValidationResult = new FieldValidationResult();
        try{
            Group group = groupManager.getGroup(groupName);
            if(group != null){
                fieldValidationResult.setHasError(false);
                fieldValidationResult.setResponse("'"+groupName+"' group found in the Jira.");
                fieldValidationResult.setField("GROUP");
            }else{
                fieldValidationResult.setHasError(true);
                fieldValidationResult.setResponse("'"+groupName+"' group not found in the Jira.");
                fieldValidationResult.setField("GROUP");
            }
        }catch (Exception e){
            LOGGER.error("Something went wrong while validation "+groupName+" field.");
            LOGGER.error(e.getMessage());
            fieldValidationResult.setHasError(true);
            fieldValidationResult.setResponse(e.getMessage());
            fieldValidationResult.setField("GROUP");
        }
        return fieldValidationResult;
    }

    /**
     * @param emails
     * @return
     */
    @Override
    public FieldValidationResult validateEmailName(String emails) {
        FieldValidationResult fieldValidationResult = new FieldValidationResult();
        try{
            String mEmails[] = emails.contains(",") ? emails.split(",") : new String[] {emails};
            String regex = "^(.+)@(.+)$";
            //Compile regular expression to get the pattern
            Pattern pattern = Pattern.compile(regex);
            //Iterate emails array list
            String invalidEmailMessaage = "";
            for(String email : mEmails){
                //Create instance of matcher
                Matcher matcher = pattern.matcher(email);
                if(!matcher.matches()){
                    invalidEmailMessaage = invalidEmailMessaage + "Invalid email address : "+email + " ";
                }
            }
            if(!invalidEmailMessaage.isEmpty()){
                fieldValidationResult.setHasError(true);
                fieldValidationResult.setResponse(invalidEmailMessaage);
                fieldValidationResult.setField("EMAIL");
            }else{
                fieldValidationResult.setHasError(false);
                fieldValidationResult.setField("EMAIL");
            }
        }catch (Exception e){
            LOGGER.error("Something went wrong while validating 'EMAIL' field.");
            LOGGER.error(e.getMessage());
            fieldValidationResult.setHasError(true);
            fieldValidationResult.setResponse(e.getMessage());
            fieldValidationResult.setField("EMAIL");
        }
        return fieldValidationResult;
    }

    /**
     * @param userCount
     * @param applicationKey
     * @return FieldValidationResult
     */
    @Override
    public FieldValidationResult validateLicenseCount(int userCount, ApplicationKey applicationKey) {
        FieldValidationResult fieldValidationResult = new FieldValidationResult();
        try{
            if(jiraLicenseManager.isLicensed(applicationKey)){
                LicenseDetails licenseDetails = jiraLicenseManager.getLicense(applicationKey).getOrNull();
                if(licenseDetails == null ){
                    fieldValidationResult.setHasError(true);
                    fieldValidationResult.setResponse("Application not found with given key "+applicationKey.toString());
                    fieldValidationResult.setField("LICENSECOUNT");
                }else{
                    LicensedApplications applications = licenseDetails.getLicensedApplications();

                    if(licenseDetails.getJiraLicense().isUnlimitedNumberOfUsers()){
                        fieldValidationResult.setHasError(false);
                        fieldValidationResult.setResponse("Application has unlimited licensed");
                        fieldValidationResult.setField("LICENSECOUNT");
                    }else {
                        int limit = applications.getUserLimit(applicationKey);
                        if (userCount < 0) {
                            fieldValidationResult.setHasError(true);
                            fieldValidationResult.setResponse("User limit:'"+userCount+"' is greater than 0.");
                            fieldValidationResult.setField("LICENSECOUNT");
                        } else if (userCount > limit) {
                            fieldValidationResult.setHasError(true);
                            fieldValidationResult.setResponse("User limit:'"+userCount+"' is greater than max User limit:'"+limit+"'.");
                            fieldValidationResult.setField("LICENSECOUNT");
                        } else {
                            fieldValidationResult.setHasError(false);
                            fieldValidationResult.setResponse("Application is not licensed");
                            fieldValidationResult.setField("LICENSECOUNT");
                        }
                    }
                }
            }else{
                fieldValidationResult.setHasError(false);
                fieldValidationResult.setResponse("Application is not licensed");
                fieldValidationResult.setField("LICENSECOUNT");
            }

        }catch (Exception e){
            LOGGER.error("Something went wrong while doing validation for Usercount: "+userCount+" field.");
            LOGGER.error(e.getMessage());
            fieldValidationResult.setHasError(true);
            fieldValidationResult.setResponse(e.getMessage());
            fieldValidationResult.setField("LICENSECOUNT");
        }
        return fieldValidationResult;
    }

    /**
     * @param applicationKey
     * @return
     */
    @Override
    public FieldValidationResult validateApplicationKey(String applicationKey) {
        FieldValidationResult fieldValidationResult = new FieldValidationResult();
        try{
            Set<ApplicationKey> appKeys = jiraLicenseManager.getAllLicensedApplicationKeys();
            boolean match = appKeys.stream().anyMatch( s -> s.value().contains(applicationKey));
            if(match){
                fieldValidationResult.setHasError(false);
                fieldValidationResult.setResponse("Application key : '"+applicationKey+"' found");
                fieldValidationResult.setField("APPLICATION");
            }else{
                fieldValidationResult.setHasError(true);
                fieldValidationResult.setResponse("Application key:'"+applicationKey+"' not found");
                fieldValidationResult.setField("APPLICATION");
            }


        }catch (Exception e){
            LOGGER.error("Something went wrong while validation 'APPLICATION' field.");
            LOGGER.error(e.getMessage());
            fieldValidationResult.setHasError(true);
            fieldValidationResult.setResponse(e.getMessage());
            fieldValidationResult.setField("APPLICATION");
        }
        return fieldValidationResult;
    }
}
