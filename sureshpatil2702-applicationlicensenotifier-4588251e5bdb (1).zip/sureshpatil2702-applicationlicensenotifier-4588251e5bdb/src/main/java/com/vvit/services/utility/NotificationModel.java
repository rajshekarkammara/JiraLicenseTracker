package com.vvit.services.utility;

public class NotificationModel {
    String applicationKey;
    int limit;
    int currentUserCount;
    Boolean isExceed;

    String email;
    String groupName;

    String applicationName;
    String totalLicenseCount;



    public NotificationModel(String applicationKey, String applicationName, int limit,Boolean isExceed,
                             String email, String groupName,int currentUserCount,String totalLicenseCount) {
        this.applicationKey = applicationKey;
        this.limit = limit;
        this.isExceed = isExceed;
        this.email = email;
        this.groupName = groupName;
        this.currentUserCount = currentUserCount;
        this.totalLicenseCount =totalLicenseCount;
        this.applicationName = applicationName;
    }

    public String getApplicationKey() {
        return applicationKey;
    }

    public void setApplicationKey(String applicationKey) {
        this.applicationKey = applicationKey;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public int getCurrentUserCount() {
        return currentUserCount;
    }

    public void setCurrentUserCount(int currentUserCount) {
        this.currentUserCount = currentUserCount;
    }

    public Boolean getExceed() {
        return isExceed;
    }

    public void setExceed(Boolean exceed) {
        isExceed = exceed;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public String getTotalLicenseCount() {
        return totalLicenseCount;
    }

    public void setTotalLicenseCount(String totalLicenseCount) {
        this.totalLicenseCount = totalLicenseCount;
    }
}
