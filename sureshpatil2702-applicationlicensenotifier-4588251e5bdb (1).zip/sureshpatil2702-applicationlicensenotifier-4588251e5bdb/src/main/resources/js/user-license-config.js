APPLICATION_LICENSE_CONFIG = {
	init: function() {
		console.log("Calling web service");
		AJS.$(document).on('click', '.action-edit-button', function(e) {
			e.preventDefault();
			console.log("Action Edit...");
			var applicationKey = jQuery(this).val();
			APPLICATION_LICENSE_CONFIG.getApplication(applicationKey);
			AJS.dialog2("#app-license-config-dialog").show();
		});

		AJS.$("#create-app-notification").on('click', function(e) {
			e.preventDefault();
			console.log("Action Add...");
			AJS.dialog2("#app-license-config-dialog").show();
		});

		// Hides the dialog

		AJS.$(document).on('click', '.action-delete-button', function(e) {
			e.preventDefault();
			console.log("Action Delete...");
			var applicationKey = jQuery(this).val();
			var $eleTr = jQuery(this).closest("tr");
			APPLICATION_LICENSE_CONFIG.deleteApplication(applicationKey, $eleTr);

		});
		AJS.$("#dialog-submit-button").on('click', function(e) {
			e.preventDefault();
			console.log("Dialog Submit...");
			var data = APPLICATION_LICENSE_CONFIG.buildJsonData();
			var flag = true;
			if(data.applicationKey.trim() == "" || data.applicationName == "" ) {
			    jQuery("#application-name-error").text("Application Name is required field.");
			    flag = false;
			}else{
			 jQuery("#application-name-error").text("");
			}

		   if(data.group.trim() == "" && data.email == "" ) {
                jQuery("#EMAIL").text("Group Name or Email is required to send notification");
		        flag = false;
		   }else{
		        jQuery("#EMAIL").text("");

		   }

		   if(data.limit.trim() == "") {
		    jQuery("#LICENSECOUNT").text("User limit is required");
		    flag = false;
		   }else{
		    jQuery("#LICENSECOUNT").text("");
		   }
		   if(flag){
		                APPLICATION_LICENSE_CONFIG.addApplication(data);

		   }

		});
		AJS.$("#dialog-close-button").on('click', function(e) {
			e.preventDefault();
			console.log("Dialog Close...");
			APPLICATION_LICENSE_CONFIG.emptyDialogField();
			AJS.dialog2("#app-license-config-dialog").hide();
		});

		AJS.$("#select2-group").auiSelect2({
			placeholder: "Search for a group",
			allowClear: true,
			ajax: { // instead of writing the function to execute the request we use Select2's convenient helper
				url: AJS.params.baseURL + "/rest/api/2/groups/picker?maxResults=10",
				dataType: 'json',
				minimumResultsForSearch: 5,
				quietMillis: 250,
				sorter: function(data) {
                    return data.sort(function (a, b) {
                        if (a.text > b.text) {
                            return 1;
                        }
                        if (a.text < b.text) {
                            return -1;
                        }
                        return 0;
                    });
                },
				data: function(term, page) {
					return {
						query: term, // search term
					};
				},
				results: function(data, page) { // parse the results into the format expected by Select2.
					// since we are using custom formatting functions we do not need to alter the remote JSON data
					return {
						results: AJS.$.map(data.groups, item => {
							return {
								text: item.name,
								value: JSON.stringify(item),
								id: item.name
							}
						})
					};
				},
				cache: true
			},
			initSelection: function(element, callback) {
				var selectedGroup = jQuery(element).val();
				var data = {
					id: selectedGroup,
					text: selectedGroup
				};
				callback(data);
			}
		});
		AJS.$("#select2-application-name").auiSelect2({
			placeholder: "Search for a application",
			allowClear: true,
			ajax: { // instead of writing the function to execute the request we use Select2's convenient helper
				url: AJS.params.baseURL + "/rest/applicationlicensehelper/1.0/config/applications",
				dataType: 'json',
				quietMillis: 250,
				data: function(term, page) {
					return {
						query: term, // search term
					};
				},
				results: function(data, page) { // parse the results into the format expected by Select2.
					// since we are using custom formatting functions we do not need to alter the remote JSON data
					return {
						results: AJS.$.map(data, item => {
							return {
								text: item.applicationName,
								id: item.applicationKey,
							}
						})
					};
				},
				cache: true
			},
			initSelection: function(element, callback) {
				var selectedApplication = jQuery(element).val();
				var selectionData = jQuery("#select2-application-name").select2("data");
				var data = {
					id: selectionData.id,
					text: selectionData.text
				};
				jQuery("#applicationKey").val(selectionData.id);
				callback(data);
			}
		});
		 /*AJS.$("#select2-application-name").on("select2-selecting", function(e) {
		    console.log ("selecting val="+ e.val+" choice="+ JSON.stringify(e.choice));
		    jQuery("#applicationKey").val(e.object.text);
		 })*/
	},
	onSubmit: function(element) {
		console.log("Submitted");
		console.log(element);
		var appKey = element.id.split("-submit")[0];
		var limitValue = jQuery("#" + appKey + "-limit-input").val();
		var groupValue = jQuery("#" + appKey + "-group-input").val();
		var emailValue = jQuery("#" + appKey + "-email-input").val();
		var applicationKey = jQuery("#" + appKey + "-key-input").val();
		var application = {
			limit: limitValue,
			group: groupValue,
			email: emailValue,
			applicationKey: applicationKey
		};

		console.log(application);

		APPLICATION_LICENSE_CONFIG.addApplication(application);

	},
	addApplication: function(data) {
		jQuery.ajax({
			url: AJS.params.baseURL + "/rest/applicationlicensehelper/1.0/config",
			type: "POST",
			data: JSON.stringify(data),
			contentType: "application/json",
			success: function(jsonData, textStatus, jqXHR) {
				console.log("SUCCESS " + jsonData);
				console.log(jsonData);
				console.log(textStatus);
				console.log(jqXHR);

				var tBody = jQuery("#manage-applications-list-container table > tbody");
				let trExist = document.getElementById(jsonData.applicationKey);
				if(trExist){
				    jQuery(trExist).remove();
				    JIRA.Messages.showSuccessMsg('License notification limit updated successfully for the ' + jsonData.applicationKey + ' application.', {
                    					closeable: true,
                    					timeout: 60
                    });
				}else{
				                JIRA.Messages.showSuccessMsg('License notification limit set successfully for the ' + jsonData.applicationKey + ' application.', {
                					closeable: true,
                					timeout: 60
                				});
				}
				var seats = "Unlimited"
				if(!jsonData.hasUnlimitedSeats){
				  seats = jsonData.totalUser
				}
				var baseURL = AJS.params.baseURL;
				jQuery(tBody).append('<tr id = "'+jsonData.applicationKey+'"> <td headers="th-app-name"><div class="application-title" style="display: inline-flex;align-content: space-around;align-items: baseline;"><h3> <span class="application-name">'+jsonData.applicationName+'</span> <span class="application-version">'+jsonData.version+'</span> </h3> <div class="application-access" style="display: inline;margin-left: 10px;"> <input class="text hidden app-key" type="text" id="'+jsonData.applicationKey+'-key-input" name="applicationKey" value="'+jsonData.applicationKey+'"> <span class="application-user-count-details">'+ seats + '<span class=""> (<a href="'+baseURL+'/secure/admin/user/UserBrowser.jspa?applicationFilter='+jsonData.applicationKey+'">'+jsonData.usedUser+' used</a>) </span> </span> </div> </div> </td> <td headers="th-usr-lic"> '+jsonData.limit+'  </td> <td headers="th-group"> '+jsonData.group+' </td> <td headers="th-email"> '+jsonData.email+' </td> <td class="action" headers="action"> <ul class="menu"> <li> <button value="'+jsonData.applicationKey+'" class="aui-button aui-button-primary action-edit-button" resolved="">Edit</button> </li> <li> <button id="action-delete-button" value="'+jsonData.applicationKey+'" class="aui-button aui-button-danger action-delete-button" resolved="">Delete</button> </li> </ul> </td> </tr>');

				jQuery(".error").text("");
				AJS.dialog2("#app-license-config-dialog").hide();
                APPLICATION_LICENSE_CONFIG.emptyDialogField();
			},
			error: function(jsonData, textStatus, errorThrown) {
				console.log("ERROR");
				console.log(jsonData);
				console.log(textStatus);
				console.log(errorThrown);
				var errorMessage = "";

				if (jsonData.hasOwnProperty("responseJSON")) {
					jsonData.responseJSON.forEach(function(it) {
						if (it.hasOwnProperty("response")) {
							console.log(it.response);
							var field = it.field;
							jQuery("#" + field).text(it.response);
						}
					})
				}
				JIRA.Messages.showErrorMsg('License notification limit not set successfully for the ' + data.applicationKey + ' application.', {
					closeable: true,
					timeout: 60
				});
			},
			complete: function(jqXHR, textStatus) {

			}
		});
	},
	getApplication: function(applicationKey) {
		jQuery.ajax({
			url: AJS.params.baseURL + "/rest/applicationlicensehelper/1.0/config?applicationKey=" + applicationKey,
			type: "GET",
			contentType: "application/json",
			success: function(jsonData, textStatus, jqXHR) {
				console.log("SUCCESS " + jsonData);
				console.log(jsonData);
				console.log(textStatus);
				console.log(jqXHR);
				jQuery("#select2-application-name").select2("data", {id: jsonData.applicationKey, text: jsonData.applicationName}); //.attr("readonly", "readonly");
				jQuery("#select2-group").select2("val", jsonData.group);
				jQuery("#email").val(jsonData.email);
				jQuery("#applicationKey").val(jsonData.applicationKey);
				jQuery("#limit").val(jsonData.limit);
			},
			error: function(jsonData, textStatus, errorThrown) {
				console.log("ERROR");
				console.log(jsonData);
				console.log(textStatus);
				console.log(errorThrown);
				var errorMessage = "";
				JIRA.Messages.showErrorMsg('Something went wrong while getting license notification configuration details for ' + applicationKey + ' application.', {
					closeable: true,
					timeout: 60
				});
			},
			complete: function(jqXHR, textStatus) {

			}
		});
	},
	deleteApplication: function(applicationKey, eleTr) {
		jQuery.ajax({
			url: AJS.params.baseURL + "/rest/applicationlicensehelper/1.0/config?applicationKey=" + applicationKey,
			type: "DELETE",
			contentType: "application/json",
			success: function(jsonData, textStatus, jqXHR) {
				console.log("SUCCESS " + jsonData);
				console.log(jsonData);
				console.log(textStatus);
				console.log(jqXHR);
				JIRA.Messages.showSuccessMsg('License notification configuration deleted successfully for the ' + applicationKey + ' application.', {
					closeable: true,
					timeout: 60
				});
				jQuery(eleTr).remove();

			},
			error: function(jsonData, textStatus, errorThrown) {
				console.log("ERROR");
				console.log(jsonData);
				console.log(textStatus);
				console.log(errorThrown);
				var errorMessage = "";
				JIRA.Messages.showErrorMsg('Something went wrong while deleting license notification configuration details for ' + applicationKey + ' application.', {
					closeable: true,
					timeout: 60
				});
			},
			complete: function(jqXHR, textStatus) {

			}
		});
	},
	emptyDialogField: function() {

		jQuery("#select2-application-name").select2("val", "");
		jQuery("#limit").val("");
		jQuery("#select2-group").select2("val", "");
		jQuery("#email").val("");
		jQuery("#applicationKey").val("");
	},
	buildJsonData: function() {
        var selectionData = jQuery("#select2-application-name").select2("data");
		var data = {
			"applicationName": selectionData.text,
			"applicationKey": selectionData.id,
			"group": jQuery("#select2-group").val(),
			"email": jQuery("#email").val(),
			"limit": jQuery("#limit").val()

		}
		return data;
	}

}
AJS.toInit(function() {
	APPLICATION_LICENSE_CONFIG.init();
});