package com.vvit.services.rest;


import org.codehaus.jackson.annotate.JsonProperty;

public class ApplicationLicenseHelperRestServiceModel {

    @JsonProperty
    private int limit;
    @JsonProperty
    private String applicationKey;
    @JsonProperty
    private String group;
    @JsonProperty
    private String email;

    @JsonProperty
    private String applicationName;
    @JsonProperty
    Boolean hasUnlimitedSeats;
    @JsonProperty
    int totalUser;
    @JsonProperty
    int usedUser;

    @JsonProperty
    String version;

    public ApplicationLicenseHelperRestServiceModel() {
    }

    public ApplicationLicenseHelperRestServiceModel(int limit, String applicationKey, String group, String email, String applicationName) {
        this.limit = limit;
        this.applicationKey = applicationKey;
        this.group = group;
        this.email = email;
        this.applicationName = applicationName;
    }

    public ApplicationLicenseHelperRestServiceModel(String applicationKey, String applicationName, Boolean hasUnlimitedSeats, int totalUser, int usedUser) {
        this.applicationKey = applicationKey;
        this.applicationName = applicationName;
        this.hasUnlimitedSeats = hasUnlimitedSeats;
        this.totalUser = totalUser;
        this.usedUser = usedUser;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public String getApplicationKey() {
        return applicationKey;
    }

    public void setApplicationKey(String applicationKey) {
        this.applicationKey = applicationKey;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Boolean getHasUnlimitedSeats() {
        return hasUnlimitedSeats;
    }

    public void setHasUnlimitedSeats(Boolean hasUnlimitedSeats) {
        this.hasUnlimitedSeats = hasUnlimitedSeats;
    }

    public int getTotalUser() {
        return totalUser;
    }

    public void setTotalUser(int totalUser) {
        this.totalUser = totalUser;
    }

    public int getUsedUser() {
        return usedUser;
    }

    public void setUsedUser(int usedUser) {
        this.usedUser = usedUser;
    }
}