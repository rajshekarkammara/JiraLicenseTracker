package com.vvit.services.service;

import com.atlassian.application.api.ApplicationKey;
import com.vvit.services.ao.UserLicenseNotifierModel;
import com.vvit.services.service.model.ApplicationModel;

import java.util.List;

public interface UserLicenseService {
    void checkUserLicenseLimitAndNotifyGroupIfExceed();
    void addUserLicenseNotificationDetails(UserLicenseNotifierModel userLicenseNotifierModel);
    UserLicenseNotifierModel getUserLicenseNotificationDetailsOfApplication(String applicationKey);
    List<ApplicationModel> getAllUserLicenseNotificationDetailsApp();
    int getNumberOfLisensedUsers(ApplicationKey applicationKey);
    int getNumberOfSeats(ApplicationKey applicationKey);
    boolean isUnlimitedLicenseApplication(String applicationKey);

}
